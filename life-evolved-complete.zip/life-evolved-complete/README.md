# Life Evolved - Milestone 1

Beautiful, calm digital ecosystem home with orbital Habitats.

## Quick Start

### Prerequisites
- Node.js 16+
- npm or yarn

### Install

```bash
npm install
```

### Run locally

```bash
npm run dev
```

Opens at http://localhost:5173

### Build for production

```bash
npm run build
```

Creates `dist/` folder ready for Cloudflare deployment.

## What's Included

- **Home V2.1 Design** - Orbital ecosystem with 7 Habitats
- **Evolving Tree** - Breathing animation in the centre
- **Forest Theme** - Dark, calm, premium aesthetic
- **Local Storage** - Persists Habitat state and theme
- **Responsive Design** - Mobile-first, works on desktop
- **Bottom Navigation** - Easy access to main areas

## Habitats

- Life
- Personal
- Health
- Work & Study
- Growth
- Hobbies
- Entertainment

## Technologies

- React 18
- TypeScript
- Vite
- CSS3 (no frameworks)

## Deployment to Cloudflare

1. Build locally:
   ```bash
   npm run build
   ```

2. Upload `dist/` folder to Cloudflare Pages

3. Set build command to: `npm run build`
4. Set build output directory to: `dist`

That's it. Your site updates automatically.

## Notes

This is a frontend prototype. No backend, auth, or database yet.
All data persists locally in browser storage.

---

**Next Milestone**: Digital Home Shell with Cells and Seed Vault
