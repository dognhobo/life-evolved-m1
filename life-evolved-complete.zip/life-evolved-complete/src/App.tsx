import { useState, useEffect } from 'react'
import Home from './pages/Home'
import './App.css'

function App() {
  const [theme, setTheme] = useState('forest')
  
  useEffect(() => {
    const saved = localStorage.getItem('life-evolved-theme')
    if (saved) setTheme(saved)
  }, [])

  useEffect(() => {
    localStorage.setItem('life-evolved-theme', theme)
    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])

  return (
    <div className="app" data-theme={theme}>
      <Home theme={theme} setTheme={setTheme} />
    </div>
  )
}

export default App
