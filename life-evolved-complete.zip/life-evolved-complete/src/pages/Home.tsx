import { useState, useEffect } from 'react'
import EcosystemStage from '../components/EcosystemStage'
import BottomNav from '../components/BottomNav'
import '../styles/home.css'

interface HomeProps {
  theme: string
  setTheme: (theme: string) => void
}

export default function Home({ theme, setTheme }: HomeProps) {
  const [habitats, setHabitats] = useState([
    { id: 'life', name: 'Life', icon: '🏠', hidden: false },
    { id: 'personal', name: 'Personal', icon: '👤', hidden: false },
    { id: 'health', name: 'Health', icon: '❤️', hidden: false },
    { id: 'work-study', name: 'Work & Study', icon: '💼', hidden: false },
    { id: 'growth', name: 'Growth', icon: '🌱', hidden: false },
    { id: 'hobbies', name: 'Hobbies', icon: '🎨', hidden: false },
    { id: 'entertainment', name: 'Entertainment', icon: '🎧', hidden: false },
  ])

  useEffect(() => {
    const saved = localStorage.getItem('life-evolved-habitats')
    if (saved) setHabitats(JSON.parse(saved))
  }, [])

  useEffect(() => {
    localStorage.setItem('life-evolved-habitats', JSON.stringify(habitats))
  }, [habitats])

  const visibleHabitats = habitats.filter(h => !h.hidden)

  return (
    <div className="home">
      <header className="home-header">
        <h1>Good morning</h1>
        <p>Let's make today exceptional.</p>
      </header>

      <EcosystemStage habitats={visibleHabitats} theme={theme} />

      <section className="home-panels">
        <div className="panel">
          <h3>Today at a glance</h3>
          <div className="panel-content">
            <div className="stat">
              <span className="stat-label">Gym</span>
              <span className="stat-value">10:00 am</span>
            </div>
            <div className="stat">
              <span className="stat-label">Team Meeting</span>
              <span className="stat-value">11:30 am</span>
            </div>
          </div>
        </div>

        <div className="panel">
          <h3>Life Snapshot</h3>
          <div className="panel-content">
            <div className="stat-row">
              <span>Sleep</span>
              <span className="stat-value">6.4h</span>
            </div>
            <div className="stat-row">
              <span>Focus</span>
              <span className="stat-value">7h 12m</span>
            </div>
          </div>
        </div>
      </section>

      <BottomNav />
    </div>
  )
}
