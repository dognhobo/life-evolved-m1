export default function BottomNav() {
  return (
    <nav className="bottom-nav">
      <button className="nav-item active">
        <span className="nav-icon">🏠</span>
        <span className="nav-label">Home</span>
      </button>
      <button className="nav-item">
        <span className="nav-icon">💡</span>
        <span className="nav-label">Insights</span>
      </button>
      <button className="nav-item">
        <span className="nav-icon">➕</span>
        <span className="nav-label">Capture</span>
      </button>
      <button className="nav-item">
        <span className="nav-icon">📅</span>
        <span className="nav-label">Calendar</span>
      </button>
      <button className="nav-item">
        <span className="nav-icon">👤</span>
        <span className="nav-label">Profile</span>
      </button>
    </nav>
  )
}
