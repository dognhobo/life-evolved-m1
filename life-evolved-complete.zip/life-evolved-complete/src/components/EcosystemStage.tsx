import EvolvingTree from './EvolvingTree'
import HabitatNode from './HabitatNode'
import '../styles/ecosystem.css'

interface Habitat {
  id: string
  name: string
  icon: string
  hidden: boolean
}

interface EcosystemStageProps {
  habitats: Habitat[]
  theme: string
}

export default function EcosystemStage({ habitats, theme }: EcosystemStageProps) {
  const getHabitatColor = (id: string): string => {
    const colors: Record<string, string> = {
      'life': '#9DBE64',
      'personal': '#A8B5A5',
      'health': '#E8795A',
      'work-study': '#9DBE64',
      'growth': '#7FC97F',
      'hobbies': '#C7A85A',
      'entertainment': '#8FA8D1',
    }
    return colors[id] || '#9DBE64'
  }

  const getOrbitRadius = (index: number, total: number): number => {
    return 140 + (index * 8)
  }

  const getAngle = (index: number, total: number): number => {
    return (index / total) * 360 - 90
  }

  return (
    <div className="ecosystem-stage">
      <svg className="orbit-rings" viewBox="0 0 400 400" preserveAspectRatio="xMidYMid meet">
        {habitats.map((_, index) => {
          const radius = getOrbitRadius(index, habitats.length)
          return (
            <circle
              key={`orbit-${index}`}
              cx="200"
              cy="200"
              r={radius}
              fill="none"
              stroke="rgba(190, 214, 162, 0.15)"
              strokeWidth="1"
            />
          )
        })}
      </svg>

      <div className="ecosystem-heart">
        <EvolvingTree />
      </div>

      <div className="habitats-container">
        {habitats.map((habitat, index) => {
          const angle = getAngle(index, habitats.length)
          const radius = 140
          const x = 200 + radius * Math.cos((angle * Math.PI) / 180)
          const y = 200 + radius * Math.sin((angle * Math.PI) / 180)

          return (
            <HabitatNode
              key={habitat.id}
              habitat={habitat}
              x={x}
              y={y}
              color={getHabitatColor(habitat.id)}
            />
          )
        })}
      </div>
    </div>
  )
}
