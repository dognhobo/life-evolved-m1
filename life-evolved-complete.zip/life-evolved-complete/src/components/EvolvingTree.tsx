export default function EvolvingTree() {
  return (
    <div className="tree-container">
      <svg
        viewBox="0 0 120 140"
        className="evolving-tree"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Roots */}
        <g className="tree-roots">
          <path
            d="M 60 130 Q 50 125 45 115"
            stroke="#9DBE64"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M 60 130 Q 70 125 75 115"
            stroke="#9DBE64"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M 60 130 Q 60 125 60 115"
            stroke="#9DBE64"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          />
        </g>

        {/* Trunk */}
        <path
          d="M 60 115 Q 58 90 59 65"
          stroke="#7FC97F"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
        />

        {/* Left branches */}
        <g className="tree-branches">
          <path
            d="M 59 100 Q 40 95 30 85"
            stroke="#9DBE64"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M 59 80 Q 35 75 20 70"
            stroke="#9DBE64"
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
          />
        </g>

        {/* Right branches */}
        <g className="tree-branches">
          <path
            d="M 61 100 Q 80 95 90 85"
            stroke="#9DBE64"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M 61 80 Q 85 75 100 70"
            stroke="#9DBE64"
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
          />
        </g>

        {/* Upper canopy */}
        <g className="tree-canopy">
          <circle cx="60" cy="50" r="22" fill="rgba(157, 190, 100, 0.3)" stroke="#9DBE64" strokeWidth="1.5" />
          <circle cx="40" cy="45" r="16" fill="rgba(157, 190, 100, 0.25)" stroke="#9DBE64" strokeWidth="1" />
          <circle cx="80" cy="45" r="16" fill="rgba(157, 190, 100, 0.25)" stroke="#9DBE64" strokeWidth="1" />
          <circle cx="60" cy="30" r="18" fill="rgba(157, 190, 100, 0.3)" stroke="#9DBE64" strokeWidth="1.5" />
        </g>

        {/* Glow effect */}
        <defs>
          <radialGradient id="treeGlow" cx="50%" cy="50%" r="60%">
            <stop offset="0%" stopColor="rgba(139, 177, 87, 0.15)" />
            <stop offset="100%" stopColor="rgba(139, 177, 87, 0)" />
          </radialGradient>
        </defs>
        <circle cx="60" cy="70" r="45" fill="url(#treeGlow)" />
      </svg>
    </div>
  )
}
