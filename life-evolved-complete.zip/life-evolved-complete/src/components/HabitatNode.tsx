interface HabitatNodeProps {
  habitat: {
    id: string
    name: string
    icon: string
  }
  x: number
  y: number
  color: string
}

export default function HabitatNode({ habitat, x, y, color }: HabitatNodeProps) {
  return (
    <button
      className="habitat-node"
      style={{
        left: `${x}px`,
        top: `${y}px`,
        borderColor: color,
        boxShadow: `0 8px 22px rgba(0, 0, 0, 0.24), 0 0 18px ${color}33`,
      }}
    >
      <span className="habitat-icon">{habitat.icon}</span>
      <span className="habitat-name">{habitat.name}</span>
    </button>
  )
}
